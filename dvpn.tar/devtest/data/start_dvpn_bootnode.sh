#!/bin/bash

/opt/marconi/bin/dvpn --region=${1}