#!/bin/bash
go build -v -o out/dvpn main.go
